package com.products.vo;

import java.util.List;

public class Products {

    private List<Product> products;

    public List<Product> getProducts() {
        return products;
    }
}
