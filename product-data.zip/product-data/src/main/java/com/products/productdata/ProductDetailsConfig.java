package com.products.productdata;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Currency;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.products.outputVO.ProductResponse;
import com.products.vo.ColorSwatch;
import com.products.vo.Price;
import com.products.vo.Product;

@Component
class ProductDetailsConfig {
	String default_label_type = "ShowWasNow";

	public static final Map<String, String> getRGB = new HashMap<String, String>();
	
    static {
    	getRGB.put("Red", "FF0000");
    	getRGB.put("Blue", "0000FF");
    	getRGB.put("Pink", "FFC0CB");
        getRGB.put("Black", "000000");
        getRGB.put("Green", "008000");
        getRGB.put("Grey", "808080");
        getRGB.put("Orange", "FFA500");
        getRGB.put("Purple", "800080");
        getRGB.put("White", "FFFFFF");
        getRGB.put("Yellow", "FFFF00");
    }
    private String currency;

    public ProductResponse toDiscountedProduct(Product product, String labelType) {
        currency = Currency.getInstance(product.getPrice().getCurrency()).getSymbol();
        if(null == labelType || labelType.isEmpty()){
        	labelType = default_label_type;
        }
        ProductResponse productResponse = new ProductResponse();
        productResponse.setProductId(product.getProductId());
        productResponse.setTitle(product.getTitle());
        productResponse.setColorSwatches(mapColorSwatches(product.getColorSwatches()));
        productResponse.setNowPrice(generatePriceString(product.getPrice().getNow()));
        productResponse.setPriceLabel(generatePriceLabel(product.getPrice(), productResponse.getNowPrice(), labelType));
        return productResponse;
    }

    private List<com.products.outputVO.ColorSwatch> mapColorSwatches(List<ColorSwatch> inputColorSwatches) {
        List<com.products.outputVO.ColorSwatch> outputColorSwatches = new ArrayList<>();
        for (ColorSwatch inputColorSwatch : inputColorSwatches) {
            com.products.outputVO.ColorSwatch outputColorSwatch = new com.products.outputVO.ColorSwatch();
            outputColorSwatch.setColor(inputColorSwatch.getColor());
            outputColorSwatch.setSkuId(inputColorSwatch.getSkuId());
            outputColorSwatch.setRgbColor(getRGB.getOrDefault(inputColorSwatch.getBasicColor(), null));
            outputColorSwatches.add(outputColorSwatch);
        }
        return outputColorSwatches;
    }

    private String generatePriceString(BigDecimal price) {
    	 String priceString=null;
    	if(null != price){
         priceString = price.toString();
        if (price.compareTo(BigDecimal.TEN) >= 0) {
            priceString = removeDecimalsFromIntegerValue(price);
            priceString= currency + priceString;
        }
    	}
        return priceString;
    }

    private String generatePriceLabel(com.products.vo.Price price, String nowPrice, String labelType) {
        String priceLabel = null;
        switch (labelType) {
            case "ShowWasNow":
                priceLabel = getShowWasNowLabel(price, nowPrice);
                break;
            case "ShowWasThenNow":
                BigDecimal thenPrice = price.getThen2() != null ? price.getThen2() : price.getThen1();
                if (thenPrice != null) {
                    priceLabel = getShowWasThenNowLabel(price, nowPrice, thenPrice);
                } else {
                    priceLabel = getShowWasNowLabel(price, nowPrice);
                }
                break;
            case "ShowPercDiscount":
                BigDecimal percentDiscount = getPercentDiscount(price);
                priceLabel = String.format("%s%% off - now %s", removeDecimalsFromIntegerValue(percentDiscount), nowPrice);
        }
        return priceLabel;
    }

    private String removeDecimalsFromIntegerValue(BigDecimal decimal) {
        String decimalString = decimal.toString();
        if (decimal.stripTrailingZeros().scale() <= 0) {
            decimalString = Integer.toString(decimal.intValue());
        }
        return decimalString;
    }
    private String getShowWasNowLabel(Price price, String nowPrice) {
        return String.format("Was %s, now %s", generatePriceString(price.getWas()), nowPrice);
    }

    private String getShowWasThenNowLabel(Price price, String nowPrice, BigDecimal thenPrice) {
        return String.format("Was %s, then %s, now %s", generatePriceString(price.getWas()), generatePriceString(thenPrice), nowPrice);
    }

    private BigDecimal getPercentDiscount(Price price) {
        return (price.getWas().subtract(price.getNow())).divide(price.getWas()).multiply(BigDecimal.valueOf(100));
    }
}
