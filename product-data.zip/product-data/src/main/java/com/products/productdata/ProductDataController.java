package com.products.productdata;

import static org.springframework.web.bind.annotation.RequestMethod.GET;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.products.outputVO.ListOfProductsResponse;
import com.products.outputVO.ProductResponse;
import com.products.vo.Product;


@RestController
public class ProductDataController {
	
	 @Autowired
	 private ProductsService productsService;
	 @Autowired
	  private ProductDetailsConfig productDeatailConfig;
	 

	 
	 @RequestMapping(value="/products", method=GET, produces = "applcation/json")
	    public ListOfProductsResponse getProducts(@RequestParam(value="labelType") String labelType) {
	        List<Product> products = productsService.getProducts();
	        List<ProductResponse> discountedProducts = new ArrayList<>();
	        for (Product product : products) {
	            if (product.getPrice().getWas() != null ) {
	                discountedProducts.add(productDeatailConfig.toDiscountedProduct(product, labelType));
	            }
	        }
	        ListOfProductsResponse response = new ListOfProductsResponse(discountedProducts);
	        return response;
	    }

}
