url used is http://localhost:8080/products?labelType=

not able to convert the object pojo to json.

Completed the coding part.But getting 406 error code